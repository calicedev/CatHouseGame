﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Cat : MonoBehaviour {
    [SerializeField]
    private int _hunger;
    [SerializeField]
    private int _happiness;
    [SerializeField]
    private int _money;
    [SerializeField]
    private string _name;
    [SerializeField]
    private string _food;

    public GameObject heart;

    private bool _serverTime;

    void Start() {
        PlayerPrefs.SetString("then", "01/07/2018 14:35:12");
        updateStatus();
        if (!PlayerPrefs.HasKey("name")) {
            PlayerPrefs.SetString("name", "Cat");
            _name = PlayerPrefs.GetString("name");
        }
    }
    private void Update()
    {
        if (Input.GetMouseButtonUp(0)) {
            Vector2 v = new Vector2(Input.mousePosition.x,Input.mousePosition.y);
            Debug.Log(v);
            RaycastHit2D hit = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(v), Vector2.zero);
            if (hit) {
                Debug.Log(hit.transform.gameObject.name);
                if (hit.transform.gameObject.tag == "whiteCat") {
                    updateMoney(2);
                }

            }

        }
    }
    void updateStatus() {
        if (!PlayerPrefs.HasKey("_hunger"))
        {
            _hunger = 100;
            PlayerPrefs.SetInt("_hunger", _hunger);
        }
        else {
            _hunger = PlayerPrefs.GetInt("_hunger");
        }
        if (!PlayerPrefs.HasKey("_happiness"))
        {
            _hunger = 100;
            PlayerPrefs.SetInt("_happiness", _hunger);
        }
        else
        {
            _hunger = PlayerPrefs.GetInt("_happiness");
        }
        if (!PlayerPrefs.HasKey("_money"))
        {
            _money = 0;
            PlayerPrefs.SetInt("_money", _money);
        }
        else
        {
            _money = PlayerPrefs.GetInt("_money");
        }
        if (!PlayerPrefs.HasKey("then"))
            PlayerPrefs.SetString("then", getStringTime());

        TimeSpan ts = getTimeSpan();
        _hunger -= (int)(ts.TotalMinutes * 1);
        if (_hunger < 0)
            _hunger = 0;

        _happiness -= (int)((100-_hunger) * (ts.TotalMinutes/5));
        if (_happiness < 0)
            _happiness = 0;

        if (_money < 0)
            _money = 0;

        Debug.Log(getTimeSpan().ToString());
        Debug.Log(getTimeSpan().TotalHours);

        if (_serverTime)
            updateServer();
        else
            InvokeRepeating ("updateDevice",0f,30f);//30초마다 시간 계속 업데이트함 

        

    }
    void updateServer() {
    }
    void updateDevice()
    {
        PlayerPrefs.SetString("then", getStringTime());
    }
    TimeSpan getTimeSpan() {
        if (_serverTime)
            return new TimeSpan();
        else
            return DateTime.Now - Convert.ToDateTime(PlayerPrefs.GetString("then"));

    }//시간과 시간사이를 빼서 시간이 얼마나 지났는지 알수 있다. 
    string getStringTime() {
        DateTime now = DateTime.Now;
        return now.Month + "/" + now.Day + "/" + now.Year + " " + now.Hour + ":" + now.Minute + ":" + now.Second;

    }
    public int hunger {
        get { return _hunger; }
        set { _hunger = value; }
    }
    public int happiness {
        get { return _happiness;}
        set { _happiness = value; }
    }
    public int money {
        get { return _money; }
        set { _money = value; }
    }
    public void updateMoney (int i){
        money += i;
        Debug.Log(money);
    }
    public string name {
        get { return _name; }
        set { _name = value; }
    }
    public string food
    {
        get { return _food; }
        set { _food = value; }
    }
    public void saveCat() {
        if (!_serverTime) {
            updateDevice();
        }
        PlayerPrefs.SetInt("_hunger",_hunger);
        PlayerPrefs.SetInt("_happiness", _happiness);
    }
    public void plusMinusHunger(int a) {
        if (a == 0)
        {
            _hunger--;
            PlayerPrefs.SetInt("_hunger", _hunger);
        }
        else if (a == 1)
        {
            _hunger++;
            PlayerPrefs.SetInt("_hunger", _hunger);
        }

    }
    public void plusMinusHappiness(int a) {
        if (a == 0)
        {
            _happiness--;
            PlayerPrefs.SetInt("_happiness", _happiness);
        }
        else if (a == 1)
        {
            _happiness++;
            PlayerPrefs.SetInt("_happiness", _happiness);
        }
    }
}

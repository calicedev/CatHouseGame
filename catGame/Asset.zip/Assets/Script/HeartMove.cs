﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeartMove : MonoBehaviour {

    public GameObject cat;
    private Vector2 pos;
    // Use this for initialization
    void Start () {
        
        pos = cat.transform.position;
		
	}
	
	// Update is called once per frame
	void Update () {
        pos = cat.transform.position;
        transform.position = new Vector2(pos.x,pos.y + (float)0.8);
	}
}

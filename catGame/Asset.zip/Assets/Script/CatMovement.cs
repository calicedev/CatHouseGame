﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CatMovement : MonoBehaviour
{
    Animator animator;

    int movementFlag;
    float restFlag;
    float moveSec, restSec;
    bool rest = false;

    public float movePower = 0.01f;
    public Vector2 speed = new Vector2(3, 3);
    private Vector2 movement;
    private Rigidbody2D rigidbodyComponent;

    private void Start()
    {
        animator = gameObject.GetComponent<Animator>();
        StartCoroutine("ChangeMovement");
        StartCoroutine("Resting");
    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        Move();
    }
    void Move()
    {
        Vector3 moveVelocity = Vector3.zero;

        switch (movementFlag)
        {
            case 0:
                movement = new Vector2(0, 1);
                break;
            case 1:
                if (rest != true)
                    movement = new Vector2(1, 0);
                else
                    movement = new Vector2(0, 0);
                break;
            case 2:
                movement = new Vector2(0, -1);
                break;
            case 3:
                if (rest != true)
                    movement = new Vector2(-1, 0);
                else
                    movement = new Vector2(0, 0);
                break;
            default:
                movement = new Vector2(0, 0);
                break;
        }
        if (rigidbodyComponent == null)
            rigidbodyComponent = GetComponent<Rigidbody2D>();
        rigidbodyComponent.velocity = movement;

    }

    void Restselect()
    {
        restFlag = Random.Range(0.0f, 2.0f);
        if (restFlag >= 1.0f)
        {
            rest = true;
        }
        else
        {
            rest = false;
        }
    }

    IEnumerator ChangeMovement()
    {
        movementFlag = Random.Range(0, 4);
        moveSec = Random.Range(2.0f, 4.0f);

        animator.SetInteger("Condition", movementFlag);

        yield return new WaitForSeconds(moveSec);
        StartCoroutine("ChangeMovement");
    }
    IEnumerator Resting()
    {
        Restselect();
        restSec = Random.Range(2.0f, 4.0f);

        animator.SetBool("rest", rest);
        if (rest)
        {
            StopCoroutine("ChangeMovement");
            yield return new WaitForSeconds(restSec);
            rest = false;
            animator.SetBool("rest", rest);
            StartCoroutine("ChangeMovement");
        }
        yield return new WaitForSeconds(3.0f);
        StartCoroutine("Resting");
    }
}
